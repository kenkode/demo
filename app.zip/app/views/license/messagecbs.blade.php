Dear sir/madam <br><br>This is cbs license for {{$organization->name}}


