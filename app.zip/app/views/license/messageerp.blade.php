Dear sir/madam <br><br>This is financials license for {{$organization->name}}


