Dear {{$name.',<br><br>'}}

Thank you for registering with cloud xara. We offer three products:<br>
1. Payroll   - Consists of Human Resource management and Salary processing for employees. It also contains itax reports, payslips, bank remittance report, NSSF and NHIF reports and many more.<br>
2. Financial - Manages Comany inventories,Clients,Suppliers and offers reports on bank reconciliation, sales summary, purcharse reports, invoices and many more.<br>
3. CBS       - Manages Sacco systems and does loans, savings, shares and sacco members. Reports include Loan application and repayments, members remittance reports, savings reports, journal entries, trial balance, income statement and balance sheet.<br><br>

Manuals for each product has been attached to enhance your betterment of the three products<br><br>

Thank you for choosing cloud xara. Please click the link below or paste the link on your browser to confirm your email address <br>
<a href="http://cloud.xara.lixnet.net/confirmation/<?php echo $key ?>">http://cloud.xara.lixnet.net/confirmation/{{$key}}</a><br><br>


For more information:<br><br>
Main offices are in Nairobi<br><br>
Address:<br>
Riara Centre, Riara Road, Nakumatt Junction<br>
Nairobi<br>
Kenya<br><br>

Sales: + 254 20 233 10 85<br>
Support: +254 20 233 11 02<br><br>

E-mail: info@lixnet.net<br>
Website: www.lixnet.net<br>
