<section class="container-slider">	
			<div id="slider">	
				<ul>
					
				<!-- Slide 1 -->		
					<li data-transition="fade" data-slotamount="7">

						<!-- Required Background Image  -->
						<img src="{{ asset('site/img/slides/bg/001.jpg') }}" alt="Image Description" />
						
						<!-- Big Multi Row Title -->

						<!-- Row 1 text -->				
								

							
											
						<!-- Image Caption -->
	                    <div class="caption lfr str" data-x="right" data-hoffset="-200" data-y="100" data-speed="500" data-start="500" data-easing="easeOutExpo">
							<div><img src="{{ asset('site/img/xara.jpg')}}" width="50%" alt="Image Description" /></div>
						</div>	
						
					</li>		
				<!-- end Slide 1 -->


				</ul>	      
			</div><!-- end Slider -->  
	 	</section>