Dear {{$user->first_name.' '.$user->last_name.',<br><br>'}}

Attached is your payslip for period {{$fperiod}}<br>
The password to unlock your payslip is ur <strong>National Identity number</strong>